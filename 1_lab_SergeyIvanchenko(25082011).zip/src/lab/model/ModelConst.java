package lab.model;
public interface ModelConst {
    public long removeCom = 1;
    public long addCom = 2;
    public long editCom = 3;
}